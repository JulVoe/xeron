#include "boost/sort/spreadsort/spreadsort.hpp"

template<class T>
void spreadsort1(T* sta, T* sto){
	boost::sort::spreadsort::spreadsort(sta, sto);
}
