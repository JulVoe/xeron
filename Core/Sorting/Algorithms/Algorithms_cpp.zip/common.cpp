#pragma once

#include <iostream>
#include <algorithm>

template<class T>
void printArray(T* p, size_t n){
	for(int i=0; i!= n; i++)
		std::cout<<*(p+i)<<"   ";
	std::cout<<std::endl;
}

template<class T>
void printArray(T* p, T* end){
	for(T* q = p; q!=end; ++q)
		std::cout<<*q<<"   ";
	std::cout<<std::endl;
}

template<class T>
void swap(T* p, T* q){ //Uses move-scematics
	T tmp = std::move(*p);
	*p = std::move(*q);
	*q = std::move(tmp);
}
