//Actually this is cocktailshaker sort, which is selectionsort but we find minimum AND MAXIMUM in every pass, effectivly halfing the number of passes!

#include "common.cpp"

template<class T>
void selectionsort1(T* sta, T* sto){
	T* max = sta;
	T* min = sta;

	while(sto-sta>1){
		for(T* p = sta; p!= sto; ++p){
			if(*p<*min)       min = p;  //A < is used to make this sort stable
			else if(*p>=*max) max = p;  //A >= is used to make this sort stabel
		}
		swap(sta,min); sta++;
		swap(sto,max); sto--;
	}
	return;
}
